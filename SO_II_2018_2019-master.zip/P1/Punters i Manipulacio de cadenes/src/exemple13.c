#include <stdio.h>

int main(void)
{
  char a[14] = "Bon dia!";

  printf("%s", a);

  return 0;
}
